<template>
    <div class="card">
        <img src="../assets/img/Placeholder_Card_Image_1.png" alt="Recipe Image" class="recipe-image" />
        <div class="card-content">
            <h6 class="recipe-title">{{ title }}</h6>
            <!-- Line Break -->
            <div class="line-break"></div>
            <div class="info-section">
                <div class="recipe-rating">★★★★★</div>
                <div class="recipe-info">
                    <i class="fas fa-clock"></i>
                    <span class="recipe-time">{{ time }} min</span>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
defineProps({
    title: {
        type: String,
        default: 'Recipe Title',
    },
    time: {
        type: String,
        default: '25',
    },
});
</script>

<style scoped>
.card {
    width: 284px;
    height: 381px;
    border-radius: 12px;
    background-color: #f8f8f8;
    padding: 20px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.recipe-image {
    width: 100%;
    height: 50%;
    /* Image takes up 50% of the card */
    object-fit: cover;
    border-radius: 8px;
    margin-bottom: 10px;
}

.card-content {
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    height: 50%;
    /* The content takes up the remaining 50% of the card */
}

.recipe-title {
    font-size: 18px;
    font-weight: bold;
    margin-bottom: 10px;
    /* Spacing between title and the line */
}

/* Line Break */
.line-break {
    height: 1px;
    background-color: #ccc;
    /* Light grey line */
    margin-bottom: 10px;
    /* Space after the line */
}

.info-section {
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    /* Push rating and time down */
    height: 100%;
}

.recipe-rating {
    color: gold;
    margin-bottom: 0px;
}

.recipe-info {
    display: flex;
    align-items: center;
}

.recipe-info .fa-clock {
    margin-right: 5px;
    color: #85A33E;
}

.recipe-time {
    font-size: 14px;
    color: #666;
    margin-left: auto;
}
</style>
