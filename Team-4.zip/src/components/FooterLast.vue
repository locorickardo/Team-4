<script setup></script>
<template>
  <div class="bg-dark py-5 mt-5">
    <div class="container text-light text-center">
      <p class="display-5 mb-3">Tasty Tales</p>
      <small class="text-white-50">&copy; Copyright by us. All rights reserved.</small>
    </div>
  </div>
</template>
<style scoped></style>
