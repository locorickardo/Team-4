<script setup>
</script>

<template>
  <div class="footer bg-dark py-5 mt-5">
    <div class="container text-light text-center">
      <!-- Footer Title -->
      <p class="display-5 mb-3">Tasty Tales</p>

      <!-- Social Media Icons and Contact Info -->
      <div class="social-icons mb-3">
        <a href="https://www.instagram.com" target="_blank" class="social-icon instagram"></a>
        <a href="https://www.youtube.com" target="_blank" class="social-icon youtube"></a>
        <a href="https://www.linkedin.com" target="_blank" class="social-icon linkedin"></a>
      </div>

      <!-- Contact Info -->
      <div class="contact-info">
        <div class="phone">
          <span class="contact-label">Telefon: </span>
          <span class="contact-value">0709672136</span>
        </div>
        <div class="email">
          <span class="contact-label">Mail: </span>
          <span class="contact-value">tastyTales@tastytales.com</span>
        </div>
      </div>

      <!-- Copyright Text -->
      <small class="text-white-50 d-block mt-3">Copyright &copy; Tasty Tales</small>
    </div>
  </div>
</template>

<style scoped>
/* Footer container styling */
.footer {
  background-color: #000 !important;
  padding-top: 3rem;
  padding-bottom: 3rem;
  margin-top: 5rem;
}

/* Title */
.display-5 {
  font-size: 2.5rem;
  font-weight: 700;
}

/* Social Icons */
.social-icons {
  display: flex;
  justify-content: center;
  gap: 20px;
}

.social-icon {
  display: block;
  width: 24px;
  height: 24px;
  background-color: #fff;
  border-radius: 50%;
}

.social-icon.x {
  background-image: url('https://upload.wikimedia.org/wikipedia/commons/6/63/X_Logo_2023.svg');
  /* X (formerly Twitter) logo */
  background-size: cover;
  background-position: center;
}

.social-icon.instagram {
  background-image: url('https://upload.wikimedia.org/wikipedia/commons/a/a5/Instagram_icon.png');
  background-size: cover;
  background-position: center;
}

.social-icon.youtube {
  background-image: url('https://upload.wikimedia.org/wikipedia/commons/a/a0/YouTube_icon_%282013-2017%29.png');
  background-size: cover;
  background-position: center;
}

.social-icon.tiktok {
  background-image: url('https://upload.wikimedia.org/wikipedia/commons/a/a7/TikTok_logo_2021.svg');
  background-size: cover;
  background-position: center;
}

/* Contact Info */
.contact-info {
  display: flex;
  justify-content: center;
  gap: 40px;
  margin-top: 1.5rem;
}

.contact-label {
  color: #BEC09C;
  font-size: 1rem;
}

.contact-value {
  color: #F4F0E8;
  font-size: 1.2rem;
}

/* Copyright Text */
.text-white-50 {
  color: rgba(255, 255, 255, 0.5);
}
</style>
