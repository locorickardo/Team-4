<script setup></script>
<template>
  <div>Recepies</div>
</template>
<style scoped></style>
