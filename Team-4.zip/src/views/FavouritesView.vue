<script setup></script>
<template>
  <div>Favourites</div>
</template>
<style scoped></style>
