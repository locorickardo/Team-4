<script setup></script>
<template>
  <div>Favorit</div>
</template>
<style scoped></style>
