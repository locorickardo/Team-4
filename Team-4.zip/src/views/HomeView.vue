<script setup>
import HeroSection from '@/components/HeroSection.vue'
import RecipeCard from '@/components/RecipeCard.vue';
</script>
<template>
  <HeroSection />
  <RecipeCard />
</template>
<style scoped></style>
