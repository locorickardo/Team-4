<script setup>
import NavBar from '../src/components/NavBar.vue'
import FooterLast from './components/FooterLast.vue';
</script>

<template>
  <NavBar />
  <RouterView />
  <FooterLast />
</template>

<style scoped></style>
